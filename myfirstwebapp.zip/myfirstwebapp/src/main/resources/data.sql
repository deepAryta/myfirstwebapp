insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE ,  DONE)
values(10001,'in28minutes', 'Get AWS Certified',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE ,  DONE)
values(10002,'in28minutes', 'Learn Spring Boot',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE ,  DONE)
values(10003,'in28minutes', 'Learn Spring Security and Microservices',CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE ,  DONE)
values(10004,'in28minutes', 'Master Full stack development',CURRENT_DATE(), false);