package com.in28minutes.springboot.myfirstwebapp.hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SayHelloController {
	
	@RequestMapping("say-hello")
	@ResponseBody	// by default controller sends the view page filename , but here we need to send string 
//	so used @ResponseBody
	public String sayHello() {
		return "Hi, What are you learning ?";
	}	
	
	@RequestMapping("say-hello-html")
	@ResponseBody
	public String sayHelloHtml() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html>");
		sb.append("<title>");
		sb.append("My first html view ");
		sb.append("</title>");
		sb.append("<body>");
		sb.append("Hi , I am learning spring");
		sb.append("</body>");
		sb.append("</html>");
		
		
		return sb.toString();
	}
	
//	<dependency>
//	<groupId>org.apache.tomcat.embed</groupId>
//	<artifactId>tomcat-embed-jasper</artifactId>
//	<scope>provided</scope>
//</dependency>
	
	@RequestMapping("say-hello-jsp")
	public String sayHelloJsp() {
		return "sayHello";
	}
	
}
